import React from "react";
import classes from "./List.module.css"
import MyButton from "../UI/button/MyButton";

function List({tasks, delTasksList, toggleCheckedTask}) {

    const removeTask = (task) => {
        delTasksList(task);
        console.log('click')
    }
    // console.log(tasks)
    return ( 
        <ul>
            {tasks !== undefined 
                ? tasks.map(task => <li key={task.id}><span onClick={e => {tasks.setChecked(task)}} 
                className={task.finishd === true 
                ? classes.finishd 
                : ''}>{task.title}</span><MyButton onClick={e => {removeTask(task)}}>Удалить</MyButton></li>) 
            : <h3>Нет заданий</h3>}
        </ul>
    );
}

export default List;