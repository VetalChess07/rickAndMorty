import React, { useRef, useState } from 'react';
import MyInput from '../UI/input/MyInput';
import MyButton from '../UI/button/MyButton';
import classes from './AddForm.module.css'


function AddForm({props, setProps}) {
    

    const [task, setTask] = useState({id: 0,finishd: false, title: ''});
    const addNewTask = (e) => {
        e.preventDefault();
        setProps(task);
        setTask({id: 0, finishd: false, title: ''});
    }

    return ( 
        <form className={classes.formList}>
            <MyInput value={task.title} onChange={e => setTask({...task, id: Date.now(), title: e.target.value})} type='text' placeholder='Заголовок поста'></MyInput>
            <MyButton onClick={addNewTask}>Add</MyButton>
        </form>
    );
}

export default AddForm;