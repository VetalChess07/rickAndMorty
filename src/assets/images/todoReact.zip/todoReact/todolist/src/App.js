import React, {useState} from "react";
import Title from "./components/Title";
import AddForm from "./components/AddForm/AddForm";
import List from "./components/List/List";



function App() {
  const [tasks, setTasks] = useState([
    {id: 1, finishd: true, title: 'Сделать верстку'},
    {id: 2, finishd: false, title: 'Посадить на битрикс'},
    {id: 3, finishd: false, title: 'Установить компосер'},
]);


  const setTasksList  = (task) => {
    setTasks([...tasks, {...task}]);
  }

  const delTasksList  = (task) => {
    setTasks(tasks.filter(t => t.id !== task.id));
  }

  const toggleCheckedTask  = (task) => {
    tasks.map(item => item.id === task.id ? item.finishd === true ? item.finishd = false : item.finishd = true : null); 
    setTasks()
    setTasks([...tasks]);
  }
console.log(tasks)
  return (
    <div>
      <Title>TodoList</Title>
      <AddForm tasks={tasks} setProps={setTasksList}></AddForm>
      <List props={tasks} delProps={delTasksList} setChecked={toggleCheckedTask}></List>
    </div>
  );
}

export default App;
